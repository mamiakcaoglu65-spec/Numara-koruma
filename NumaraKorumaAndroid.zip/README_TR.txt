NUMARA KORUMA — Android proje dosyaları

Bu kaynak proje şüpheli telefon numaralarını cihazda yerel olarak kaydetmek,
WhatsApp sohbetini açmaya çalışmak ve engelleme/şikâyet rehberi sunmak için hazırlanmıştır.

ÖNEMLİ SINIRLAR
- Başka birinin WhatsApp hesabını kapatamaz.
- Numaranın dolandırıcı olduğunu otomatik doğrulamaz.
- WhatsApp'a otomatik şikâyet göndermez; kullanıcı işlemi WhatsApp içinde yapar.
- Kaydedilen notlar ve numaralar cihazın uygulama verilerinde tutulur; buluta gönderilmez.

APK oluşturma:
1. Android Studio'yu bilgisayarınıza kurun.
2. Bu ZIP dosyasını açın.
3. Android Studio > Open ile NumaraKorumaAndroid klasörünü seçin.
4. Gradle senkronizasyonunun tamamlanmasını bekleyin.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
6. APK genellikle app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.

Telefonunuza kurmak için APK'yı telefona aktarın ve yalnızca kendi oluşturduğunuz/güvendiğiniz APK'yı yükleyin.
