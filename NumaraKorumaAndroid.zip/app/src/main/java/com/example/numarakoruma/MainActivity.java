package com.example.numarakoruma;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private EditText numberInput, noteInput;
    private LinearLayout listLayout;
    private SharedPreferences prefs;
    private final String KEY = "saved_cases";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("NumaraKoruma", MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        root.setBackgroundColor(0xFFF7F9F7);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("🛡️ Numara Koruma");
        title.setTextSize(27);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFF176B45);
        root.addView(title);

        TextView intro = new TextView(this);
        intro.setText("Şüpheli numaraları kendi telefonunda kaydet, WhatsApp'ta engelleme veya şikâyet adımlarına ulaş.");
        intro.setTextSize(16);
        intro.setTextColor(0xFF303830);
        intro.setPadding(0, dp(10), 0, dp(18));
        root.addView(intro);

        numberInput = new EditText(this);
        numberInput.setSingleLine(true);
        numberInput.setHint("Telefon numarası (ülke koduyla)");
        numberInput.setInputType(3);
        root.addView(numberInput, params());

        noteInput = new EditText(this);
        noteInput.setHint("Not (ör. sahte ödeme bağlantısı)");
        root.addView(noteInput, params());

        Button save = button("Numarayı kaydet");
        root.addView(save, params());
        save.setOnClickListener(v -> saveNumber());

        Button open = button("WhatsApp'ta aç");
        root.addView(open, params());
        open.setOnClickListener(v -> openWhatsApp());

        Button guide = button("Engelleme ve şikâyet rehberi");
        root.addView(guide, params());
        guide.setOnClickListener(v -> showGuide());

        TextView warning = new TextView(this);
        warning.setText("Not: Bu uygulama başka birinin hesabını kapatamaz ve numaranın dolandırıcı olduğunu doğrulamaz. WhatsApp değerlendirmeyi kendisi yapar. Yalnızca doğrulanabilir olayları bildirin.");
        warning.setTextSize(13);
        warning.setTextColor(0xFF6B4E16);
        warning.setPadding(dp(12), dp(12), dp(12), dp(12));
        warning.setBackgroundColor(0xFFFFF1D6);
        LinearLayout.LayoutParams wp = params();
        wp.topMargin = dp(12);
        root.addView(warning, wp);

        TextView listTitle = new TextView(this);
        listTitle.setText("Kaydedilen numaralar");
        listTitle.setTextSize(20);
        listTitle.setTypeface(null, Typeface.BOLD);
        listTitle.setPadding(0, dp(24), 0, dp(8));
        root.addView(listTitle);

        listLayout = new LinearLayout(this);
        listLayout.setOrientation(LinearLayout.VERTICAL);
        root.addView(listLayout, params());
        setContentView(scroll);
        refreshList();
    }

    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams params() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }
    private String cleanNumber(String raw) {
        return raw.replaceAll("[^0-9+]", "").replaceFirst("^\\+", "");
    }
    private void saveNumber() {
        String n = cleanNumber(numberInput.getText().toString().trim());
        String note = noteInput.getText().toString().trim();
        if (n.length() < 7 || n.length() > 15 || n.startsWith("0")) {
            Toast.makeText(this, "Numarayı ülke koduyla yaz. Örnek: 905xxxxxxxxx", Toast.LENGTH_LONG).show();
            return;
        }
        LinkedHashMap<String,String> items = loadItems();
        items.put(n, note);
        saveItems(items);
        numberInput.setText("");
        noteInput.setText("");
        refreshList();
        Toast.makeText(this, "Numara bu telefona kaydedildi.", Toast.LENGTH_SHORT).show();
    }
    private void openWhatsApp() {
        String n = cleanNumber(numberInput.getText().toString().trim());
        if (n.isEmpty()) {
            Toast.makeText(this, "Önce ülke koduyla numarayı gir.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + n));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "WhatsApp veya tarayıcı açılamadı.", Toast.LENGTH_LONG).show();
        }
    }
    private void showGuide() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("WhatsApp'ta engelleme / şikâyet")
            .setMessage("1. WhatsApp'ta ilgili sohbeti açın.\n2. Üstteki kişi/numara bilgisine dokunun.\n3. Aşağı kaydırıp Engelle veya Şikâyet et seçeneklerini kullanın.\n4. Dolandırıcılık kanıtlarını (mesaj, dekont, bağlantı) saklayın.\n\nAcil maddi kayıp veya tehdit varsa bankanızla ve yerel kolluk birimleriyle de iletişime geçin.")
            .setPositiveButton("Tamam", null).show();
    }
    private LinkedHashMap<String,String> loadItems() {
        LinkedHashMap<String,String> out = new LinkedHashMap<>();
        String raw = prefs.getString(KEY, "");
        if (raw.isEmpty()) return out;
        for (String line : raw.split("\\n")) {
            int ix = line.indexOf('|');
            if (ix > 0) {
                String n = line.substring(0, ix);
                String note = line.substring(ix + 1).replace("\\\\n", " ");
                out.put(n, note);
            }
        }
        return out;
    }
    private void saveItems(LinkedHashMap<String,String> items) {
        StringBuilder b = new StringBuilder();
        for (Map.Entry<String,String> e : items.entrySet()) {
            b.append(e.getKey()).append("|").append(e.getValue().replace("|", "/").replace("\n", " ")).append("\n");
        }
        prefs.edit().putString(KEY, b.toString()).apply();
    }
    private void refreshList() {
        if (listLayout == null) return;
        listLayout.removeAllViews();
        LinkedHashMap<String,String> items = loadItems();
        if (items.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Henüz numara kaydedilmedi.");
            listLayout.addView(empty);
            return;
        }
        for (Map.Entry<String,String> e : items.entrySet()) {
            final String number = e.getKey();
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackgroundColor(0xFFFFFFFF);
            TextView text = new TextView(this);
            text.setText(number + (e.getValue().isEmpty() ? "" : "\nNot: " + e.getValue()));
            text.setTextSize(16);
            row.addView(text);
            LinearLayout actions = new LinearLayout(this);
            Button open = button("WhatsApp'ta aç");
            open.setOnClickListener(v -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + number))); }
                catch (Exception ex) { Toast.makeText(this, "Açılamadı.", Toast.LENGTH_SHORT).show(); }
            });
            Button delete = button("Sil");
            delete.setOnClickListener(v -> {
                LinkedHashMap<String,String> updated = loadItems();
                updated.remove(number);
                saveItems(updated);
                refreshList();
            });
            actions.addView(open, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            actions.addView(delete, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(actions);
            LinearLayout.LayoutParams rp = params();
            rp.bottomMargin = dp(8);
            listLayout.addView(row, rp);
        }
    }
}
